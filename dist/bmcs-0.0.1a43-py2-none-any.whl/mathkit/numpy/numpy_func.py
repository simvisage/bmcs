def Heaviside(x):
    ''' Heaviside function '''
    return x >= 0
