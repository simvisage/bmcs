============
Introduction
============

The package implements the framework for the simulation
of structural and material behavior of 
brittle-matrix composite structures combining cementitious
matrix with various types of reinforcement.

It serves as a general solver of nonlinear structural
behavior with highly configurable model representation.
