'''
Created on Jul 12, 2017

@author: rch
'''
from bmcs.pullout.pullout_multilinear import PullOutModel
from view.window import BMCSWindow


class PullOutMultilinearBondStudy(BMCSWindow):

    title = 'Pullout with piecewise linear bond-slip law'
    desc = '''The pull-out response is calculated for specifying the values 
    explicitly specified bond-slip law.
'''

    def __init__(self, *args, **kw):
        self.model = PullOutModel(name='e32_pullout_multilinear',
                                  n_e_x=100, k_max=1000, w_max=1.84)
        self.model.tline.step = 0.01
        self.model.geometry.L_x = 200.0
        self.model.loading_scenario.set(loading_type='monotonic')
        self.model.cross_section.set(A_f=16.67, P_b=1.0, A_m=1540.0)
        self.model.mats_eval.set(s_data='0, 0.1, 0.4, 4.0',
                                 tau_data='0, 800, 0, 0')
        self.model.mats_eval.update_bs_law = True
        self.model.run()

        self.add_viz2d('load function', 'load-time')
        self.add_viz2d('F-w', 'load-displacement')
        self.add_viz2d('field', 'u_C', plot_fn='u_C')
        self.add_viz2d('dissipation', 'dissipation')
        self.add_viz2d('field', 'eps_C', plot_fn='eps_C')
        self.add_viz2d('field', 's', plot_fn='s')
        self.add_viz2d('field', 'sig_C', plot_fn='sig_C')
        self.add_viz2d('field', 'sf', plot_fn='sf')


def run_pullout_multilinear(*args, **kw):
    w = PullOutMultilinearBondStudy()
    w.offline = False
    w.finish_event = True
    w.configure_traits(*args, **kw)


if __name__ == '__main__':
    run_pullout_multilinear()
