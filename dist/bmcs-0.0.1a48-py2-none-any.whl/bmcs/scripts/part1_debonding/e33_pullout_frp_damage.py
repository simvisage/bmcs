'''
Created on Jul 12, 2017

@author: rch
'''
from bmcs.pullout.pullout_frp_damage import PullOutModel
from view.window import BMCSWindow


class PullOutFRPDamageBondStudy(BMCSWindow):

    title = 'Pullout with bond damage-softening'
    desc = '''This example demonstrates the local nature of debonding
    with propagating damage process zone. Notice the constant 
    energy release rate.
'''

    def __init__(self, *args, **kw):
        self.model = PullOutModel(name='e33_pullout_frp_damage',
                                  n_e_x=100, k_max=500, w_max=1.0)
        self.model.tline.step = 0.01
        self.model.geometry.L_x = 500.0
        self.model.loading_scenario.set(loading_type='monotonic')
        self.model.cross_section.set(A_f=16.67, P_b=1.0, A_m=1540.0)
        # self.model.mats_eval.set()
        self.model.mats_eval.omega_fn.set(b=10.4, Gf=1.19, plot_max=0.5)
        self.model.run()

        self.add_viz2d('load function', 'load-time')
        self.add_viz2d('F-w', 'load-displacement')
        self.add_viz2d('field', 'u_C', plot_fn='u_C')
        self.add_viz2d('field', 'w', plot_fn='w')
        self.add_viz2d('field', 'eps_C', plot_fn='eps_C')
        self.add_viz2d('field', 's', plot_fn='s')
        self.add_viz2d('field', 'sig_C', plot_fn='sig_C')
        self.add_viz2d('field', 'sf', plot_fn='sf')
        self.add_viz2d('dissipation', 'dissipation')
        self.add_viz2d('dissipation rate', 'dissipation rate')


def run_pullout_frp_damage(*args, **kw):
    w = PullOutFRPDamageBondStudy()
    w.offline = False
    w.finish_event = True
    w.configure_traits(*args, **kw)


if __name__ == '__main__':
    run_pullout_frp_damage()
