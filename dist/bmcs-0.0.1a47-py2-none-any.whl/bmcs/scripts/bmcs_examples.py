'''
Created on Jul 17, 2017

@author: rch
'''

from reporter import Reporter
import part1_debonding.t21_bond_slip_damage
import part1_debonding.t22_bond_slip_plasticity
import part1_debonding.t23_bond_slip_damage_plasticity
import part1_debonding.t31_pullout_frictional
import part1_debonding.t32_pullout_multilinear
import part1_debonding.t33_pullout_frp_damage

if __name__ == '__main__':

    r = Reporter()
    r.studies = [
        part1_debonding.t21_bond_slip_damage.construct_bond_slip_study(),
        #         part1_debonding.t22_bond_slip_plasticity.construct_bond_slip_study(),
        #         part1_debonding.t23_bond_slip_damage_plasticity.construct_bond_slip_study(),
        #         part1_debonding.t31_pullout_frictional.construct_pullout_study(),
        #         part1_debonding.t32_pullout_multilinear.construct_pullout_study(),
        #         part1_debonding.t33_pullout_frp_damage.construct_pullout_study(),
    ]
    r.write()
    r.show_tex()
    r.run_pdflatex()
    r.show_pdf()
