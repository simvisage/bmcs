
from traits.api import Interface

class IFESubDomain( Interface ):
    '''Subdomain interface
    '''