'''
Created on Jul 11, 2017

@author: rch
'''

CURRENT_VERSION = '0.0.1a57'
