'''
Created on Jul 15, 2017

@author: rch
'''
from traits.api import \
    HasStrictTraits, Instance, Str
from view.window import BMCSModel
from view.window.bmcs_viz_sheet import VizSheet
