
from traits.api import Interface

class ISDomain( Interface ):
    '''
    Interface of the spatial domain.
    '''
