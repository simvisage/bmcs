'''Manager for the current experiment design
'''