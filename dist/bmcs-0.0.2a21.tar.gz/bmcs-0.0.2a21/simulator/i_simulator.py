'''
Created on Dec 17, 2018

@author: rch
'''

from traits.api import Interface


class ISimulator(Interface):
    r'''
    '''
